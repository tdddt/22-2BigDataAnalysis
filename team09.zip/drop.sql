use team09;

drop table 간암체크리스트;
drop table 위암체크리스트;
drop table 대장암체크리스트;
drop table 폐암체크리스트;
drop table patient;
drop table checkresult;
drop table cancerComment;
drop table cancerinfo;
drop table doctorcomment;
drop table doctorinfo;
drop table hospitalcomment;
drop TABLE hospitalinfo;
drop table userinfo;
drop table userlog;